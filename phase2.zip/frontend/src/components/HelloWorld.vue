<template>
  <div class="container">
    <div class="dates">
    <h3>Start Date</h3>
    <b-form-datepicker  v-model="startDate" class="mb-2"></b-form-datepicker>
    <p>{{ startDate }}</p>
    <h3>End Date</h3>
    <b-form-datepicker  v-model="endDate" class="mb-2"></b-form-datepicker>
    <p>{{ endDate }}</p>
     <b-button variant="danger" @click="onSubmit">Get Analysis</b-button>
  </div>

<div class="tables" v-for="service in this.data" :key="service">
       <h3>{{service.service}}</h3>
       <table >
        <tr>
          <th></th>
          <th>CPU</th>
          <th>DISK</th>
          <th>RAM</th>
        </tr>
          <th>Utilization</th>
          <th>{{service.cpu}}</th>
          <th>{{service.disk}}</th>
          <th>{{service.ram}}</th>
        <tr>
        
        </tr>
        <tr>
          <th>Max Time</th>
          <th>{{service.cpuMT}}</th>
          <th>{{service.diskMT}}</th>
          <th>{{service.ramMT}}</th>
        </tr>
      </table>
      <p>Messages: {{service.count}}</p>
</div>

  </div>
 

</template>


<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
   components: {
  },
  data () {
    return {
      startDate: '',
      endDate: '',
      data: [],
    }
  },
  methods: {
    parseJSON(text){
      let m=text.json();
       console.log(m);
      return m;
    },
    async onSubmit(event) {
      event.preventDefault();
      let response=await fetch(
        "http://localhost:8085/getAnalysis/" +
          this.startDate +
          "/" +
          this.endDate,
        {
         method: "get",
        })
        .then(this.parseJSON);
          // console.log(response);
          this.data = response;
    },
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.container
{
  width: 60%;
}

.vdp-datepicker {
    position: relative;
    text-align: center;
}
.tables{
  text-align: center;
  width: 100%;
}
table, th, td {
  border: 1px solid;
}
table{
  margin: 0 120px;
}
th,td{
  padding: 10px;
}
</style>
